package com.example.sharedpreference;

        import android.content.SharedPreferences;
        import android.os.Bundle;
        import android.view.View;
        import android.widget.Button;
        import android.widget.EditText;
        import androidx.appcompat.app.AppCompatActivity;

public class Register extends AppCompatActivity{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register);

        final EditText ID = (EditText) findViewById(R.id.etID);
        final EditText email = (EditText) findViewById(R.id.etNewEmail);
        final EditText Name = (EditText) findViewById(R.id.etName);
        final EditText password = (EditText) findViewById(R.id.etPassword);
        final EditText conpassword = (EditText) findViewById(R.id.etConPassword);
        Button btnRegister = (Button) findViewById(R.id.btnNewRegister);


        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                SharedPreferences preferences = getSharedPreferences("MYPREFS",MODE_PRIVATE);
                String newID = ID.getText().toString();
                String newEmail = email.getText().toString();
                String newUser = Name.getText().toString();
                String newPassword = password.getText().toString();
                String newConPassword = conpassword.getText().toString();

                SharedPreferences.Editor editor = preferences.edit();
                editor.putString(newID, newID);
                editor.commit();
                editor.putString(newEmail, newEmail);
                editor.commit();
                editor.putString(newUser,newUser);
                editor.commit();
                editor.putString(newPassword, newPassword);
                editor.commit();
                editor.putString(newConPassword, newConPassword);
                editor.commit();
                editor.putString(newUser + newPassword + "data", newUser + "\n" + newEmail);
                editor.commit();
            }
        });

    }

}
