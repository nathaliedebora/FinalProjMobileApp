package com.example.sharedpreference;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final EditText etID = (EditText) findViewById(R.id.etID);
        final EditText etEmail = (EditText) findViewById(R.id.etNewEmail);
        final EditText etName = (EditText) findViewById(R.id.etName);
        final EditText etPassword = (EditText) findViewById(R.id.etPassword);
        final EditText etConPassword = (EditText) findViewById(R.id.etConPassword);
        Button btnLogin = (Button) findViewById(R.id.btnLogin);
        Button btnRegister = (Button) findViewById(R.id.btnRegister);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String newID = etID.getText().toString();
                String newEmail = etEmail.getText().toString();
                String newUser = etName.getText().toString();
                String newPassword= etPassword.getText().toString();
                String newConPassword = etConPassword.getText().toString();


                SharedPreferences preferences = getSharedPreferences("MYPREFS", MODE_PRIVATE);

                String userDetails = preferences.getString(newUser + newPassword + "data","No information on that user.");
                SharedPreferences.Editor editor = preferences.edit();
                editor.putString(newID, newID);
                editor.commit();
                editor.putString(newEmail, newEmail);
                editor.commit();
                editor.putString(newUser,newUser);
                editor.commit();
                editor.putString(newPassword, newPassword);
                editor.commit();
                editor.putString(newConPassword, newConPassword);
                editor.commit();
                editor.putString("display",userDetails);
                editor.commit();

                Intent displayScreen = new Intent(MainActivity.this, Login.class);
                startActivity(displayScreen);

                if(newID.equals("")){
                    Toast.makeText( MainActivity.this, "ID is blank", Toast.LENGTH_LONG).show();
                }
                if(newEmail.equals("")){
                    Toast.makeText( MainActivity.this, "Email is blank", Toast.LENGTH_LONG).show();
                }
                if(newUser.equals("")){
                    Toast.makeText( MainActivity.this, "Name is blank", Toast.LENGTH_LONG).show();
                }
                if(newPassword.equals("")){
                    Toast.makeText( MainActivity.this, "Password is blank", Toast.LENGTH_LONG).show();
                }
                else if(newConPassword.equals("")){
                    Toast.makeText(MainActivity.this, "Confirmation Password is blank", Toast.LENGTH_LONG).show();
                }
            }
        });


        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent registerScreen = new Intent(MainActivity.this, Register.class);
                startActivity(registerScreen);
            }
        });
    }



}
